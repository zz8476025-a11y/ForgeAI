import { useMemo, useState } from "react";
import {
  Activity,
  AppWindow,
  ArrowRight,
  Bell,
  Bot,
  Box,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Code2,
  Command,
  Cpu,
  Database,
  Download,
  Eye,
  FileCode2,
  FileJson,
  Folder,
  FolderOpen,
  GitBranch,
  Globe2,
  Image as ImageIcon,
  Layers3,
  LayoutDashboard,
  LockKeyhole,
  MessageSquareText,
  MoreHorizontal,
  PanelLeftClose,
  PanelRightClose,
  Play,
  Plus,
  RefreshCw,
  Rocket,
  Search,
  Send,
  Settings2,
  Sparkles,
  Square,
  TerminalSquare,
  Undo2,
  WandSparkles,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

const navItems = [
  { label: "Workspace", icon: LayoutDashboard },
  { label: "Projects", icon: Layers3 },
  { label: "Templates", icon: Box },
  { label: "Assets", icon: ImageIcon },
];

const projectFiles = [
  { name: "src", type: "folder", open: true },
  { name: "App.tsx", type: "tsx", active: true },
  { name: "components", type: "folder" },
  { name: "screens", type: "folder" },
  { name: "services", type: "folder" },
  { name: "assets", type: "folder" },
  { name: "app.config.ts", type: "tsx" },
  { name: "package.json", type: "json" },
  { name: "README.md", type: "md" },
];

const codeLines = [
  ["import", " React from ", "'react'", ";"],
  ["import", " { SafeAreaView, Text, Pressable } ", "from", " 'react-native'", ";"],
  ["import", " { Sparkles, ArrowRight } ", "from", "'@/icons'", ";"],
  ["", ""],
  ["export", " default ", "function", " ForgeHome", "() {"],
  ["", "  const", " [prompt, setPrompt]", " = useState('')"],
  ["", "  const", " [isBuilding, setIsBuilding]", " = useState(false)"],
  ["", ""],
  ["", "  const", " handleBuild", " = () => {"],
  ["", "    setIsBuilding(true)"],
  ["", "    createProject({ prompt, platform: 'android' })"],
  ["", "  }"],
  ["", ""],
  ["", "  return ("],
  ["", "    <SafeAreaView", " style={styles.container}", ">"],
  ["", "      <View", " style={styles.header}", ">"],
  ["", "        <Sparkles", " color={colors.violet}", " />"],
  ["", "        <Text", " style={styles.title}", ">Build with AI</Text>"],
  ["", "      </View>"],
  ["", "      <Pressable", " onPress={handleBuild}", " style={styles.promptCard}", ">"],
  ["", "        <Text", " style={styles.promptLabel}", ">Your next idea</Text>"],
  ["", "        <Text", " style={styles.promptText}", ">"],
  ["", "          {prompt || 'Describe what you want to build...'}"],
  ["", "        </Text>"],
  ["", "      </Pressable>"],
  ["", "      <Button", " onPress={handleBuild}", " loading={isBuilding}", ">"],
  ["", "        Build with AI", " <ArrowRight size={16} />"],
  ["", "      </Button>"],
  ["", "    </SafeAreaView>"],
  ["", "  )"],
  ["}"],
];

const quickActions = [
  { label: "Android app", icon: AppWindow, color: "violet" },
  { label: "2D game", icon: Zap, color: "orange" },
  { label: "Website", icon: Globe2, color: "cyan" },
  { label: "AI tool", icon: Bot, color: "pink" },
];

function IconForFile({ type }: { type: string }) {
  if (type === "folder") return <Folder size={14} className="file-icon folder-icon" />;
  if (type === "json") return <FileJson size={14} className="file-icon json-icon" />;
  if (type === "md") return <FileCode2 size={14} className="file-icon md-icon" />;
  return <FileCode2 size={14} className="file-icon code-icon" />;
}

export default function Home() {
  const [activeNav, setActiveNav] = useState("Workspace");
  const [activeTab, setActiveTab] = useState("code");
  const [prompt, setPrompt] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [isBuilding, setIsBuilding] = useState(false);
  const [previewState, setPreviewState] = useState("ready");
  const [chatMessages, setChatMessages] = useState([
    { role: "ai", text: "I’m ready to shape the next version of ForgeHome. What should we improve?" },
  ]);
  const [selectedFile, setSelectedFile] = useState("App.tsx");
  const [showFileRail, setShowFileRail] = useState(true);
  const [showAgent, setShowAgent] = useState(true);

  const statusLabel = useMemo(() => {
    if (isBuilding) return "Building project";
    if (previewState === "running") return "Preview running";
    return "All systems operational";
  }, [isBuilding, previewState]);

  const startBuild = (value = prompt) => {
    const buildPrompt = value.trim() || "a polished Android app";
    setPrompt(buildPrompt);
    setIsBuilding(true);
    setPreviewState("building");
    toast.success("Build started", { description: "Forge is planning your project architecture." });
    window.setTimeout(() => {
      setIsBuilding(false);
      setPreviewState("running");
      setChatMessages((messages) => [
        ...messages,
        { role: "ai", text: `Plan ready. I mapped ${buildPrompt.toLowerCase()} into a modular starter with navigation, state, and a live preview.` },
      ]);
      toast.success("Preview updated", { description: "Your latest project changes are now live." });
    }, 1800);
  };

  const sendChat = (value = chatInput) => {
    const trimmed = value.trim();
    if (!trimmed) return;
    setChatMessages((messages) => [
      ...messages,
      { role: "user", text: trimmed },
      { role: "ai", text: "I’ll apply that as a focused project change and keep the existing architecture intact." },
    ]);
    setChatInput("");
    toast("Agent queued a change", { description: trimmed });
  };

  const runPreview = () => {
    setPreviewState("running");
    toast.success("Preview running", { description: "Android emulator connected to localhost." });
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><Sparkles size={17} strokeWidth={2.2} /></div>
          <div>
            <div className="brand-name">BuildForge <span>AI</span></div>
            <div className="brand-context">Workspace / ForgeHome</div>
          </div>
        </div>
        <div className="topbar-center">
          <div className="status-pill"><span className="pulse-dot" /> {statusLabel}</div>
          <div className="sync-label"><GitBranch size={13} /> main <span className="sync-divider">·</span> synced 2m ago</div>
        </div>
        <div className="topbar-actions">
          <button className="icon-button" aria-label="Notifications" onClick={() => toast("No new notifications")}><Bell size={17} /></button>
          <button className="icon-button" aria-label="Help" onClick={() => toast("Forge help center is coming soon")}><CircleHelp size={17} /></button>
          <div className="avatar">JR</div>
        </div>
      </header>

      <div className="workspace-layout">
        <aside className="sidebar">
          <button className="new-project-button" onClick={() => { setPrompt(""); toast("New project draft ready"); }}><Plus size={16} /> New project <span className="shortcut">⌘ N</span></button>
          <div className="sidebar-section-label">Build</div>
          <nav className="main-nav">
            {navItems.map(({ label, icon: Icon }) => (
              <button key={label} className={`nav-item ${activeNav === label ? "active" : ""}`} onClick={() => { setActiveNav(label); toast(`${label} view selected`); }}>
                <Icon size={16} /> <span>{label}</span>{label === "Projects" && <span className="nav-count">6</span>}
              </button>
            ))}
          </nav>
          <div className="sidebar-section-label project-label">Current project</div>
          <div className="current-project-card">
            <div className="project-symbol"><Code2 size={17} /></div>
            <div className="project-copy"><strong>ForgeHome</strong><span>Android app</span></div>
            <button className="tiny-icon-button" aria-label="Project menu"><MoreHorizontal size={15} /></button>
          </div>
          <div className="sidebar-section-label">Project tools</div>
          <nav className="tool-nav">
            <button className="nav-item" onClick={() => toast("AI usage: 72% used this month")}><Cpu size={16} /><span>AI usage</span><span className="usage-dot" /></button>
            <button className="nav-item" onClick={() => toast("Deployment center is ready for your first deploy")}><Rocket size={16} /><span>Deployments</span></button>
            <button className="nav-item" onClick={() => toast("Settings opened")}><Settings2 size={16} /><span>Settings</span></button>
          </nav>
          <div className="sidebar-bottom">
            <div className="plan-card"><div className="plan-top"><span>Pro plan</span><span className="plan-badge">ACTIVE</span></div><div className="plan-meter"><span /></div><div className="plan-meta"><span>AI usage</span><strong>72%</strong></div></div>
            <div className="sidebar-profile"><div className="avatar small">JR</div><div><strong>Jordan Rivers</strong><span>Personal workspace</span></div><ChevronDown size={14} /></div>
          </div>
        </aside>

        <main className="main-workspace">
          <div className="workspace-toolbar">
            <div className="breadcrumb"><span>Projects</span><ChevronRight size={14} /><strong>ForgeHome</strong><span className="beta-badge">MVP</span></div>
            <div className="toolbar-actions"><button className="toolbar-button" onClick={() => toast("Changes are already saved")}><Activity size={14} /> Saved</button><button className="toolbar-button" onClick={() => toast("Invite link copied")}><Plus size={14} /> Share</button><button className="toolbar-button primary" onClick={() => toast("Deploy flow opened")}><Rocket size={14} /> Deploy <ChevronDown size={13} /></button></div>
          </div>

          <section className="hero-prompt-section">
            <div className="eyebrow"><span className="eyebrow-icon"><WandSparkles size={13} /></span> AI project builder <span className="eyebrow-line" /></div>
            <h1>What do you want to <em>build?</em></h1>
            <p className="hero-subtitle">Describe an idea. Forge handles the architecture, code, assets, and the first working preview.</p>
            <div className="prompt-composer">
              <div className="prompt-icon"><Sparkles size={18} /></div>
              <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Describe your app, game, website, software, or image..." rows={2} onKeyDown={(event) => { if ((event.metaKey || event.ctrlKey) && event.key === "Enter") startBuild(); }} />
              <div className="prompt-footer"><span className="prompt-hint"><Command size={12} /> Enter to build</span><button className="build-button" onClick={() => startBuild()} disabled={isBuilding}>{isBuilding ? <RefreshCw size={15} className="spin" /> : <Sparkles size={15} />} {isBuilding ? "Building..." : "Build with AI"} <ArrowRight size={15} /></button></div>
            </div>
            <div className="quick-actions">{quickActions.map(({ label, icon: Icon, color }) => <button key={label} className="quick-action" onClick={() => { setPrompt(`Create a ${label} with a polished first-run experience`); toast(`${label} starter selected`); }}><span className={`quick-icon ${color}`}><Icon size={15} /></span>{label}<ArrowRight size={13} /></button>)}</div>
          </section>

          <section className="workspace-grid">
            <div className={`file-panel ${showFileRail ? "" : "collapsed"}`}>
              <div className="panel-heading"><div><span className="panel-kicker">Explorer</span><strong>ForgeHome</strong></div><button className="panel-icon-button" aria-label="Collapse explorer" onClick={() => setShowFileRail(!showFileRail)}>{showFileRail ? <PanelLeftClose size={15} /> : <PanelRightClose size={15} />}</button></div>
              {showFileRail && <>
                <div className="file-search"><Search size={13} /><span>Filter files</span><span className="file-search-key">⌘ P</span></div>
                <div className="file-tree"><div className="tree-root"><ChevronDown size={13} /><FolderOpen size={14} className="folder-icon" /><span>ForgeHome</span></div>{projectFiles.map((file, index) => <button key={`${file.name}-${index}`} className={`file-row ${file.active || selectedFile === file.name ? "selected" : ""} ${file.type === "folder" ? "folder-row" : ""}`} onClick={() => file.type !== "folder" && setSelectedFile(file.name)}><span className="indent" style={{ width: file.type === "folder" ? 11 : 27 }} />{file.type === "folder" && (file.open ? <ChevronDown size={12} /> : <ChevronRight size={12} />)}<IconForFile type={file.type} /><span>{file.name}</span>{file.active && <span className="unsaved-dot" />}</button>)}</div>
                <div className="explorer-footer"><span><GitBranch size={12} /> main</span><span><LockKeyhole size={12} /> private</span></div>
              </>}
            </div>

            <div className="editor-preview-column">
              <div className="editor-panel">
                <div className="editor-tabs"><div className="editor-tab active"><FileCode2 size={14} className="code-icon" />{selectedFile}<span className="tab-dot" /><X size={13} /></div><button className="editor-add"><Plus size={14} /></button><div className="editor-tools"><button onClick={() => toast("Command palette opened")}><Command size={14} /></button><button onClick={() => toast("Search in project") }><Search size={14} /></button><button onClick={() => toast("More editor actions") }><MoreHorizontal size={15} /></button></div></div>
                <div className="code-editor"><div className="line-numbers">{codeLines.map((_, index) => <span key={index}>{String(index + 1).padStart(2, "0")}</span>)}</div><pre>{codeLines.map((parts, index) => <code key={index} className="code-line">{parts.map((part, partIndex) => <span key={partIndex} className={partIndex === 0 && ["import", "export"].includes(part) ? "token-keyword" : part.includes("'") ? "token-string" : part.includes("function") || part.includes("handleBuild") ? "token-function" : part.includes("const") ? "token-keyword" : ""}>{part}</span>)}</code>)}</pre><div className="editor-minimap"><span /><span /><span /><span /><span /><span /><span /></div></div>
                <div className="editor-statusbar"><span><GitBranch size={12} /> main</span><span>TypeScript React</span><span>Ln 18, Col 32</span><span>UTF-8</span></div>
              </div>

              <div className="preview-panel">
                <div className="preview-heading"><div className="preview-tabs"><button className={activeTab === "code" ? "active" : ""} onClick={() => setActiveTab("code")}><Code2 size={14} /> Code</button><button className={activeTab === "preview" ? "active" : ""} onClick={() => setActiveTab("preview")}><Eye size={14} /> Preview</button><button className={activeTab === "assets" ? "active" : ""} onClick={() => setActiveTab("assets")}><ImageIcon size={14} /> Assets</button></div><div className="preview-controls"><span className="device-selector"><AppWindow size={13} /> Android phone <ChevronDown size={12} /></span><button onClick={() => setPreviewState("idle")}><Square size={12} fill="currentColor" /></button><button onClick={runPreview}><Play size={13} fill="currentColor" /></button><button onClick={() => toast("Preview refreshed")}><RefreshCw size={13} /></button><button onClick={() => toast("Preview window opened")}><MoreHorizontal size={14} /></button></div></div>
                <div className="preview-canvas"><div className="phone-preview"><div className="phone-status"><span>9:41</span><span>● ◔ ▰</span></div><div className="phone-content"><div className="phone-welcome"><div className="phone-brand"><span className="phone-brand-mark"><Sparkles size={14} /></span><span>forgehome</span></div><span className="phone-avatar">JR</span></div><div className="phone-headline">Build something <em>brilliant.</em></div><p className="phone-copy">Your next idea is closer than you think.</p><div className="phone-card"><span className="mini-label">AI BUILDER</span><strong>{prompt ? prompt.slice(0, 24) + (prompt.length > 24 ? "…" : "") : "Start with an idea"}</strong><div className="mini-input"><Sparkles size={12} /><span>Tell me what to build</span><ArrowRight size={12} /></div></div><div className="phone-section-title"><span>Quick starts</span><span>See all</span></div><div className="phone-quick-grid"><div><span className="phone-quick-icon purple"><AppWindow size={15} /></span><small>App</small></div><div><span className="phone-quick-icon orange"><Zap size={15} /></span><small>Game</small></div><div><span className="phone-quick-icon blue"><Globe2 size={15} /></span><small>Web</small></div><div><span className="phone-quick-icon pink"><ImageIcon size={15} /></span><small>Image</small></div></div><div className="phone-bottom-nav"><span className="selected"><LayoutDashboard size={15} />Home</span><span><Layers3 size={15} />Projects</span><span className="create"><Plus size={17} /></span><span><Bot size={15} />AI</span><span><Settings2 size={15} />Profile</span></div></div></div>{previewState === "building" && <div className="preview-overlay"><div className="build-orb"><Sparkles size={21} /></div><strong>Forge is building</strong><span>Generating your first preview…</span><div className="build-progress"><span /></div></div>}{previewState === "idle" && <div className="preview-idle"><Square size={18} fill="currentColor" /><span>Preview stopped</span><button onClick={runPreview}>Run preview</button></div>}<div className="canvas-caption"><span><span className="live-dot" /> Live preview</span><span>Updated just now</span></div></div>
              </div>
            </div>

            {showAgent && <aside className="agent-panel"><div className="agent-heading"><div className="agent-title"><span className="agent-avatar"><Sparkles size={15} /></span><div><strong>Forge Agent</strong><span>Project-aware copilot</span></div></div><button className="panel-icon-button" onClick={() => setShowAgent(false)}><PanelRightClose size={15} /></button></div><div className="agent-context"><span className="context-dot" /> Context synced <span>·</span> ForgeHome</div><div className="chat-messages">{chatMessages.map((message, index) => <div className={`chat-message ${message.role}`} key={`${message.role}-${index}`}>{message.role === "ai" && <span className="chat-avatar"><Sparkles size={12} /></span>}<div className="message-bubble">{message.text}</div></div>)}{isBuilding && <div className="chat-message ai"><span className="chat-avatar"><Sparkles size={12} /></span><div className="message-bubble typing"><i /><i /><i /></div></div>}</div><div className="suggestion-list"><span className="suggestion-label">Try asking</span><button onClick={() => sendChat("Add a dark mode toggle")}>Add a dark mode toggle <ArrowRight size={12} /></button><button onClick={() => sendChat("Make the home screen feel more premium")}>Make the home screen more premium <ArrowRight size={12} /></button><button onClick={() => sendChat("Show me what changed")}>Show me what changed <ArrowRight size={12} /></button></div><div className="chat-composer"><textarea value={chatInput} onChange={(event) => setChatInput(event.target.value)} placeholder="Ask Forge to change anything…" rows={2} onKeyDown={(event) => { if ((event.metaKey || event.ctrlKey) && event.key === "Enter") sendChat(); }} /><div className="chat-compose-footer"><span><Command size={11} /> Enter</span><button onClick={() => sendChat()} aria-label="Send message"><Send size={14} /></button></div></div><div className="agent-footer"><span><LockKeyhole size={11} /> Changes are sandboxed</span><button onClick={() => toast("Agent activity opened")}><MoreHorizontal size={13} /></button></div></aside>}
          </section>

          <div className="bottom-strip"><div className="bottom-tabs"><button className="active"><TerminalSquare size={14} />Terminal <span className="tab-count">1</span></button><button><Activity size={14} />Logs</button><button><Database size={14} />Database</button></div><div className="terminal-content"><span className="terminal-prompt">$</span><span>forge dev</span><span className="terminal-muted">› Starting development server...</span><span className="terminal-success">ready in 1.8s</span></div><button className="undo-button" onClick={() => toast("Last agent change reverted") }><Undo2 size={13} /> Undo last change</button></div>
        </main>
      </div>

      {!showAgent && <button className="agent-reopen" onClick={() => setShowAgent(true)}><Sparkles size={15} /> Open Forge Agent</button>}
    </div>
  );
}
